# Change Log

## [1.0.0] 2018-08-14
### Original Release
